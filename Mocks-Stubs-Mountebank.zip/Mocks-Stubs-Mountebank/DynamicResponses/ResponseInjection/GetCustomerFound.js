function GetTemplateResponse (request, state, logger) {
response = JSON.parse("<%- stringify(filename, '\\StubTemplate\\CustomerFoundView.json') %>");
//response = JSON.parse("C:\\Mocking\\Mocks-Stubs-Mountebank\\DynamicResponses\\StubTemplate\\CustomerFoundView.json");
//console.log('Response is '+response);
var ext = require('C:\\Mocking\\Mocks-Stubs-Mountebank\\DynamicResponses\\ResponseInjection\\extractrequest.js');
var reqdata = ext.extractor(request);
console.log(reqdata.CustomerID);
console.log(response.cspCustomerId);
response.cspCustomerId=reqdata.CustomerID;
return {
statusCode : 200,
headers: {
'Content-Type': 'application/json; charset=utf-8'
},
body: response
};
}